__author__ = 'Ilya Markov'

from pyclick.search_session.SearchResult import SearchResult
from pyclick.search_session.SearchSession import SearchSession
